import json

from app import config
from app.geofence import Geofence


def first_point(plate):
    with open(config.ROUTES_FILE) as f:
        routes = json.load(f)
    v = [v for v in routes["vehicles"] if v["plate"] == plate][0]
    return v["points"]


def test_ambulance_start_point_is_inside_lane():
    fence = Geofence()
    t, lat, lon = first_point("DL01EA1001")[5]
    assert fence.contains(lat, lon)


def test_middle_lane_car_is_outside_lane():
    fence = Geofence()
    for t, lat, lon in first_point("UP32GH5555"):
        assert not fence.contains(lat, lon)


def test_far_away_point_is_outside():
    fence = Geofence()
    assert not fence.contains(19.0760, 72.8777)   # Mumbai, far from the demo lane
