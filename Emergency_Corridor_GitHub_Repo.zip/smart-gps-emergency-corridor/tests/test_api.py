from fastapi.testclient import TestClient

from app.main import app

client = TestClient(app)


def setup_function():
    client.post("/api/reset")


def test_health_and_corridor():
    assert client.get("/api/health").json() == {"status": "ok"}
    geo = client.get("/api/corridor").json()
    assert geo["features"][0]["geometry"]["type"] == "Polygon"


def lane_point():
    ring = client.get("/api/corridor").json()["features"][0]["geometry"]["coordinates"][0]
    # middle of the first lane cross-section = a point inside the lane
    lon = (ring[1][0] + ring[-2][0]) / 2
    lat = (ring[1][1] + ring[-2][1]) / 2
    return lat, lon


def test_full_flow_gps_challan_waiver():
    lat, lon = lane_point()
    r = client.post("/api/gps", json={"plate": "HR26DK9090", "lat": lat, "lon": lon, "timestamp": 1000})
    assert r.json()["events"][0]["event"] == "TIMER_STARTED"
    r = client.post("/api/tick", params={"timestamp": 1016})
    assert r.json()["events"][0]["event"] == "E_CHALLAN_ISSUED"
    cid = client.get("/api/challans").json()[0]["challan_id"]
    r = client.post(f"/api/challans/{cid}/waiver",
                    data={"hospital_name": "AIIMS New Delhi", "timestamp": 1100},
                    files={"slip": ("slip.png", b"fake-bytes", "image/png")})
    assert r.json()["status"] == "WAIVED"


def test_helpline_sms_endpoint():
    r = client.post("/api/helpline/sms", json={"from_number": "+91-0000000000",
                                               "message": "EMERGENCY DL03CQ7788 to AIIMS"})
    body = r.json()
    assert body["ok"] and body["plate"] == "DL03CQ7788"


def test_map_page_served():
    r = client.get("/map")
    assert r.status_code == 200
    assert "leaflet" in r.text.lower()
