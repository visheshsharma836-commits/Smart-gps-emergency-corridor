from app import config
from app.engine import CorridorEngine
from app.whitelist import find_plate, normalize_plate


class FakeFence:
    """A simple fence for tests: 'inside' means latitude > 0."""
    geojson = {}

    def contains(self, lat, lon):
        return lat > 0


def make_engine():
    from app.whitelist import Whitelist
    return CorridorEngine(geofence=FakeFence(), whitelist=Whitelist())


def names(events):
    return [e["event"] for e in events]


def test_plate_helpers():
    assert normalize_plate("dl 01 ea-1001") == "DL01EA1001"
    assert find_plate("EMERGENCY dl03cq7788 to AIIMS") == "DL03CQ7788"
    assert find_plate("help please") is None


def test_whitelisted_ambulance_gets_access_no_timer():
    eng = make_engine()
    ev = eng.update_gps("DL01EA1001", 1, 0, now=0)
    assert names(ev) == ["ACCESS_GRANTED"]
    eng.update_gps("DL01EA1001", 1, 0, now=30)
    assert eng.challans == {}


def test_private_car_gets_challan_after_15_seconds():
    eng = make_engine()
    assert names(eng.update_gps("HR26DK9090", 1, 0, now=100)) == ["TIMER_STARTED"]
    assert eng.tick(now=100 + config.GRACE_SECONDS - 1) == []
    ev = eng.tick(now=100 + config.GRACE_SECONDS)
    assert names(ev) == ["E_CHALLAN_ISSUED"]
    assert len(eng.challans) == 1


def test_car_leaving_in_time_gets_no_challan():
    eng = make_engine()
    eng.update_gps("DL08CX4521", 1, 0, now=0)
    ev = eng.update_gps("DL08CX4521", -1, 0, now=10)    # back to normal lane
    assert names(ev) == ["LEFT_IN_TIME"]
    eng.tick(now=60)
    assert eng.challans == {}


def test_helpline_sms_stops_timer_and_whitelists():
    eng = make_engine()
    eng.update_gps("DL03CQ7788", 1, 0, now=0)
    reply = eng.helpline_message("+91-0000000000", "EMERGENCY DL03CQ7788 to AIIMS", now=5)
    assert reply["ok"] and "Temporary Corridor Access Granted" in reply["reply"]
    assert names(eng.events)[-2:] == ["TEMP_WHITELISTED", "TIMER_STOPPED"]
    eng.update_gps("DL03CQ7788", 1, 0, now=40)
    eng.tick(now=40)
    assert eng.challans == {}


def test_temporary_access_expires():
    eng = make_engine()
    eng.helpline_message("+91-0000000000", "DL03CQ7788", now=0)
    later = config.TEMP_WHITELIST_MINUTES * 60 + 1
    assert not eng.whitelist.is_allowed("DL03CQ7788", later)


def test_slip_waiver_approved_and_rejected():
    eng = make_engine()
    eng.update_gps("HR26DK9090", 1, 0, now=0)
    eng.tick(now=20)
    cid = eng.challan_for_plate("HR26DK9090")["challan_id"]

    bad = eng.upload_slip(cid, "slip.exe", b"x", "Unknown Clinic", now=30)
    assert bad["ok"] is False and len(bad["reasons"]) == 2

    good = eng.upload_slip(cid, "slip.png", b"fake-image-bytes", "AIIMS New Delhi", now=40)
    assert good["ok"] is True and eng.challans[cid]["status"] == "WAIVED"
