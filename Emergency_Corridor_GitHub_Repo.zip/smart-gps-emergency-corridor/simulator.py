"""
Simulator: moves demo vehicles along real GPS points and shows what the
corridor system does. No server needed.

    python simulator.py                 # fast run, prints all events
    python simulator.py --speed 1       # real time (1 simulated second = 1 second)
    python simulator.py --server http://127.0.0.1:8000 --speed 2
                                        # sends the GPS points to the running API,
                                        # so you can watch them on the live map

The vehicles, their GPS tracks and the helpline/slip actions come from
sample_data/routes.json. All number plates are fake.
"""
import argparse
import json
import time
from datetime import datetime, timedelta

from app import config
from app.engine import CorridorEngine

START = datetime(2026, 10, 27, 9, 0, 0)   # demo clock shown in the log


def clock(t):
    return (START + timedelta(seconds=t)).strftime("%H:%M:%S")


def load_routes():
    with open(config.ROUTES_FILE, encoding="utf-8") as f:
        return json.load(f)


class LocalBackend:
    """Runs the engine inside this script."""

    def __init__(self):
        self.engine = CorridorEngine()

    def gps(self, plate, lat, lon, t):
        return self.engine.update_gps(plate, lat, lon, t)

    def tick(self, t):
        return self.engine.tick(t)

    def sms(self, from_number, message, t):
        before = len(self.engine.events)
        reply = self.engine.helpline_message(from_number, message, t)
        return reply, self.engine.events[before:]

    def upload(self, plate, hospital, path, t):
        ch = self.engine.challan_for_plate(plate)
        if ch is None:
            return None, []
        with open(config.BASE_DIR / path, "rb") as f:
            data = f.read()
        before = len(self.engine.events)
        self.engine.upload_slip(ch["challan_id"], path, data, hospital, t)
        return ch["challan_id"], self.engine.events[before:]


class ServerBackend:
    """Sends everything to the running FastAPI server (for the live map)."""

    def __init__(self, url):
        import requests  # only needed in server mode
        self.requests = requests
        self.url = url.rstrip("/")
        self.base = time.time()
        self.count = 0   # how many server events we have already shown
        self.requests.post(self.url + "/api/reset", timeout=5)

    def _new_events(self):
        events = self.requests.get(self.url + "/api/events", params={"limit": 100000}, timeout=5).json()
        new = events[self.count:]
        self.count = len(events)
        return new

    def _ts(self, t):
        return self.base + t

    def gps(self, plate, lat, lon, t):
        r = self.requests.post(self.url + "/api/gps", timeout=5,
                               json={"plate": plate, "lat": lat, "lon": lon, "timestamp": self._ts(t)})
        events = r.json()["events"]
        self.count += len(events)
        return events

    def tick(self, t):
        events = self.requests.post(self.url + "/api/tick", params={"timestamp": self._ts(t)},
                                    timeout=5).json()["events"]
        self.count += len(events)
        return events

    def sms(self, from_number, message, t):
        reply = self.requests.post(self.url + "/api/helpline/sms", timeout=5,
                                   json={"from_number": from_number, "message": message,
                                         "timestamp": self._ts(t)}).json()
        return reply, self._new_events()

    def upload(self, plate, hospital, path, t):
        challans = self.requests.get(self.url + "/api/challans", timeout=5).json()
        mine = [c for c in challans if c["plate"] == plate]
        if not mine:
            return None, []
        cid = mine[-1]["challan_id"]
        with open(config.BASE_DIR / path, "rb") as f:
            self.requests.post(self.url + f"/api/challans/{cid}/waiver", timeout=5,
                               data={"hospital_name": hospital, "timestamp": self._ts(t)},
                               files={"slip": (path.split("/")[-1], f, "image/png")})
        return cid, self._new_events()


def main():
    parser = argparse.ArgumentParser(description="Emergency corridor simulator")
    parser.add_argument("--speed", type=float, default=0,
                        help="0 = as fast as possible, 1 = real time, 2 = 2x faster ...")
    parser.add_argument("--server", default=None, help="URL of the running API, e.g. http://127.0.0.1:8000")
    parser.add_argument("--log", default=str(config.LOG_DIR / "simulation_log.txt"))
    args = parser.parse_args()

    routes = load_routes()
    backend = ServerBackend(args.server) if args.server else LocalBackend()
    tracks = {v["plate"]: {p[0]: (p[1], p[2]) for p in v["points"]} for v in routes["vehicles"]}
    actions = {}
    for a in routes["actions"]:
        actions.setdefault(a["t"], []).append(a)

    lines = []

    def show(t, text):
        line = f"[{clock(t)}] {text}"
        print(line)
        lines.append(line)

    show(0, "=== Smart GPS Geofenced Emergency Corridor - simulation start ===")
    for v in routes["vehicles"]:
        show(0, f"Vehicle {v['plate']:<11} : {v['label']}")
    show(0, f"Rules: grace timer {config.GRACE_SECONDS}s, helpline access "
            f"{config.TEMP_WHITELIST_MINUTES} min, all plates are FAKE demo plates")
    show(0, "-" * 70)

    for t in range(routes["duration_seconds"] + 1):
        events = []
        for plate, track in tracks.items():
            if t in track:
                lat, lon = track[t]
                events += backend.gps(plate, lat, lon, t)
        events += backend.tick(t)
        for a in actions.get(t, []):
            if a["action"] == "helpline_sms":
                show(t, f"SMS to helpline {config.HELPLINE_NUMBER} from {a['from_number']}: \"{a['message']}\"")
                reply, ev = backend.sms(a["from_number"], a["message"], t)
                events += ev
                show(t, f"Helpline reply: \"{reply['reply']}\"")
            elif a["action"] == "upload_slip":
                show(t, f"{a['plate']} uploads a slip from '{a['hospital_name']}' via helpline")
                cid, ev = backend.upload(a["plate"], a["hospital_name"], a["file"], t)
                events += ev
        for e in events:
            show(t, f"{e['event']:<17} {e['message']}")
        if args.speed > 0:
            time.sleep(1 / args.speed)

    show(routes["duration_seconds"], "-" * 70)
    if isinstance(backend, LocalBackend):
        eng = backend.engine
        show(routes["duration_seconds"], "SUMMARY")
        counts = {}
        for e in eng.events:
            counts[e["event"]] = counts.get(e["event"], 0) + 1
        for k, n in counts.items():
            show(routes["duration_seconds"], f"  {k:<17} x {n}")
        for ch in eng.challans.values():
            show(routes["duration_seconds"],
                 f"  Challan {ch['challan_id']} | {ch['plate']} | Rs {ch['amount_inr']} | {ch['status']}")
    show(routes["duration_seconds"], "=== simulation end ===")

    config.LOG_DIR.mkdir(exist_ok=True)
    with open(args.log, "w", encoding="utf-8") as f:
        f.write("\n".join(lines) + "\n")
    print(f"\nLog saved to {args.log}")


if __name__ == "__main__":
    main()
