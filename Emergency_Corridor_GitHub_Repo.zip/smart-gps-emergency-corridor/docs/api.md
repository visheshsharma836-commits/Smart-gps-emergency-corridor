# API Reference

Base URL when running locally: `http://127.0.0.1:8000`
Interactive docs (try every endpoint in the browser): `http://127.0.0.1:8000/docs`

All times are Unix seconds. `timestamp` is optional everywhere; if you leave it out,
the server uses the current time.

---

### `GET /api/health`
Check that the server is running.
```json
{"status": "ok"}
```

### `GET /api/corridor`
The virtual emergency lane as GeoJSON (a polygon).

### `POST /api/gps`
A vehicle sends its position.

Request:
```json
{"plate": "HR26DK9090", "lat": 28.57301, "lon": 77.20945, "timestamp": 1000}
```
Response:
```json
{
  "vehicle": {"plate": "HR26DK9090", "in_lane": true, "status": "TIMER", "timer_started": 1000, "...": "..."},
  "events": [{"time": 1000, "event": "TIMER_STARTED", "plate": "HR26DK9090",
              "message": "HR26DK9090 is NOT whitelisted. Warning sent: ..."}]
}
```

### `POST /api/tick?timestamp=1016`
Checks all running 15-second timers. Creates e-challans for cars still in the lane.

### `POST /api/helpline/sms`
Mock SMS / WhatsApp helpline. The plate is found inside the message text.

Request:
```json
{"from_number": "+91-9800000001", "message": "EMERGENCY DL03CQ7788 patient to AIIMS"}
```
Response:
```json
{"ok": true, "plate": "DL03CQ7788", "valid_until": 1800,
 "reply": "Temporary Corridor Access Granted for DL03CQ7788 (valid 30 min). Drive safely."}
```
If no plate is found: `"ok": false` with a help message.

### `GET /api/challans`
List of all mock e-challans.
```json
[{"challan_id": "ECH-DEMO-00001", "plate": "HR26DK9090", "amount_inr": 10000,
  "status": "ISSUED", "seconds_in_lane": 15.0, "location": {"lat": 28.57, "lon": 77.20}}]
```

### `POST /api/challans/{challan_id}/waiver`
Upload a hospital/clinic slip (form-data).

| Field | Type | Example |
|---|---|---|
| `slip` | file (PDF/JPG/PNG, max 5 MB) | `sample_hospital_slip.png` |
| `hospital_name` | text | `AIIMS New Delhi` |
| `timestamp` | number (optional) | `1100` |

Example with curl:
```bash
curl -X POST http://127.0.0.1:8000/api/challans/ECH-DEMO-00001/waiver \
  -F "hospital_name=AIIMS New Delhi" \
  -F "slip=@sample_data/sample_hospital_slip.png"
```
Response:
```json
{"ok": true, "challan_id": "ECH-DEMO-00001", "status": "WAIVED", "reasons": []}
```

### `GET /api/events?limit=50`
The latest events (the system log).

### `GET /api/state`
Everything the live map needs: vehicles (with `seconds_left` for running timers),
challans and the last 15 events.

### `POST /api/reset`
Clears all vehicles, events and challans.

---

## Event types

| Event | Meaning |
|---|---|
| `ACCESS_GRANTED` | Whitelisted vehicle entered the lane |
| `TIMER_STARTED` | Non-whitelisted vehicle entered, 15 s grace timer started |
| `LEFT_IN_TIME` | Vehicle left within 15 s, no fine |
| `TEMP_WHITELISTED` | Helpline message accepted, plate allowed for 30 min |
| `TIMER_STOPPED` | Timer stopped because of the helpline message |
| `E_CHALLAN_ISSUED` | Vehicle stayed more than 15 s, mock challan created |
| `EXITED_LANE` | Vehicle left the lane |
| `WAIVER_APPROVED` | Slip accepted, challan waived |
| `WAIVER_REJECTED` | Slip rejected, with reasons |
