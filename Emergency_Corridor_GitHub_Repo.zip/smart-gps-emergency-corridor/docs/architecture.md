# Architecture

This document explains how the prototype is built. Everything here runs on one
laptop. The "Future" boxes are not built yet.

## Big picture

```mermaid
flowchart TB
    subgraph Vehicles
        AMB[🚑 Ambulance with RTK-GPS]
        CAR[🚗 Private car / driver phone]
    end
    subgraph People
        FAM[👨‍👩‍👧 Family with patient]
    end
    subgraph Backend [Cloud backend - FastAPI prototype]
        API[REST API<br>app/main.py]
        ENG[Corridor Engine<br>app/engine.py]
        GEO[Geofence<br>app/geofence.py]
        WL[Whitelist<br>app/whitelist.py]
        CH[E-challan + slip check<br>app/challan.py]
    end
    MAP[🗺️ Live map<br>app/static/map.html]

    AMB -- GPS ping --> API
    CAR -- GPS ping --> API
    FAM -- SMS / WhatsApp to helpline --> API
    API --> ENG
    ENG --> GEO
    ENG --> WL
    ENG --> CH
    API -- /api/state every 0.5 s --> MAP

    WL -. future .-> VAHAN[(VAHAN database)]
    CH -. future .-> RTO[(RTO e-challan portal)]
    ENG -. future .-> SIG[Traffic signal pre-emption]
```

## Modules

| File | Job |
|---|---|
| `app/config.py` | All numbers and file paths (15 s timer, 30 min access, 48 h waiver window) |
| `app/geofence.py` | Loads the lane polygon (GeoJSON) and checks if a GPS point is inside it |
| `app/whitelist.py` | Permanent list (VAHAN-like CSV) + temporary list (helpline). Finds a plate in an SMS |
| `app/challan.py` | Creates a mock e-challan; mock check of the uploaded hospital/clinic slip |
| `app/engine.py` | The decision logic. Keeps the state of every vehicle and the event log |
| `app/main.py` | FastAPI server: turns HTTP requests into engine calls |
| `app/static/map.html` | Leaflet map that shows the lane, vehicles, timers, challans |
| `simulator.py` | Plays the demo story from `sample_data/routes.json` |

## Vehicle states

```mermaid
stateDiagram-v2
    [*] --> OUTSIDE
    OUTSIDE --> ALLOWED: enters lane and is whitelisted
    OUTSIDE --> TIMER: enters lane, NOT whitelisted
    TIMER --> OUTSIDE: leaves within 15 s (no fine)
    TIMER --> ALLOWED: family SMSes the helpline (timer stopped)
    TIMER --> CHALLANED: still inside after 15 s
    CHALLANED --> OUTSIDE: leaves lane
    ALLOWED --> OUTSIDE: leaves lane
```

A challan itself has its own status: `ISSUED` → `WAIVED` (slip accepted) or stays `ISSUED` (slip rejected).

## Main flow (sequence)

```mermaid
sequenceDiagram
    participant Car as Private car (GPS)
    participant API as Backend
    participant Fam as Family phone
    participant Map as Live map
    Car->>API: POST /api/gps (inside lane)
    API-->>Car: warning, 15 s timer started
    API-->>Map: vehicle shown in red with countdown
    Fam->>API: POST /api/helpline/sms "EMERGENCY DL03CQ7788"
    API-->>Fam: "Temporary Corridor Access Granted"
    API-->>Map: vehicle shown in orange (temporary)
```

## The geofence

- Stored in `sample_data/corridor_lane.geojson` as a polygon.
- Demo location: leftmost lane of Aurobindo Marg (southbound) in New Delhi, towards AIIMS.
  The road line was taken from OpenStreetMap and the lane was drawn 2 m to 5.5 m to the
  left of it. This is a demo drawing, not an official corridor.
- Check used: `polygon.contains(Point(lon, lat))` from shapely.

## Why RTK-GPS?

A lane is about 3.5 m wide. Normal phone GPS can be off by 3 to 10 m, so it can confuse
two lanes. RTK-GPS can reach centimetre-level accuracy, which is needed for a real
lane-level system. The prototype simply assumes accurate GPS points.

## What is mocked (fake) in the prototype

| Real system | Prototype |
|---|---|
| VAHAN database | `sample_data/vahan_whitelist.csv` (fake plates) |
| 112 SMS / WhatsApp gateway | `POST /api/helpline/sms` |
| RTO e-challan portal | a Python dictionary with a demo challan number |
| AI/OCR slip verification | simple rules: file type, size, hospital name in list, 48 h window |
| Vehicles on the road | `simulator.py` + `sample_data/routes.json` |
