"""
Web server (REST API) of the prototype, built with FastAPI.

Run it:   uvicorn app.main:app --reload
Open:     http://127.0.0.1:8000/map     (live map)
          http://127.0.0.1:8000/docs    (automatic API documentation)
"""
from pathlib import Path
from typing import Optional

from fastapi import FastAPI, File, Form, HTTPException, UploadFile
from fastapi.responses import FileResponse, RedirectResponse
from pydantic import BaseModel

from .engine import CorridorEngine

app = FastAPI(
    title="Smart GPS Geofenced Emergency Corridor System",
    description="Prototype API: virtual emergency lane, 15-second timer, helpline whitelist, "
                "mock e-challan and mock slip waiver. All data is demo data.",
    version="0.1.0",
)

STATIC_DIR = Path(__file__).resolve().parent / "static"
engine = CorridorEngine()


# ----- request bodies -----
class GpsPing(BaseModel):
    plate: str
    lat: float
    lon: float
    timestamp: Optional[float] = None   # seconds; if empty, server time is used


class HelplineMessage(BaseModel):
    from_number: str
    message: str                        # e.g. "EMERGENCY DL03CQ7788 to AIIMS"
    timestamp: Optional[float] = None


# ----- pages -----
@app.get("/", include_in_schema=False)
def home():
    return RedirectResponse("/map")


@app.get("/map", include_in_schema=False)
def live_map():
    return FileResponse(STATIC_DIR / "map.html")


# ----- API -----
@app.get("/api/health")
def health():
    return {"status": "ok"}


@app.get("/api/corridor")
def corridor():
    """The virtual lane as GeoJSON (to draw on the map)."""
    return engine.geofence.geojson


@app.post("/api/gps")
def gps(ping: GpsPing):
    """A vehicle sends its GPS position. Returns the new events."""
    events = engine.update_gps(ping.plate, ping.lat, ping.lon, ping.timestamp)
    vehicle = engine.vehicles[events[0]["plate"] if events else ping.plate.upper().replace(" ", "")]
    return {"vehicle": vehicle, "events": events}


@app.post("/api/tick")
def tick(timestamp: Optional[float] = None):
    """Check all 15-second timers now."""
    return {"events": engine.tick(timestamp)}


@app.post("/api/helpline/sms")
def helpline_sms(msg: HelplineMessage):
    """Mock SMS / WhatsApp helpline. Finds the plate and whitelists it for 30 minutes."""
    return engine.helpline_message(msg.from_number, msg.message, msg.timestamp)


@app.get("/api/challans")
def challans():
    return list(engine.challans.values())


@app.post("/api/challans/{challan_id}/waiver")
async def waiver(challan_id: str,
                 hospital_name: str = Form(...),
                 slip: UploadFile = File(...),
                 timestamp: Optional[float] = Form(None)):
    """Upload a hospital/clinic slip. Mock verification, then the fine is waived."""
    if challan_id not in engine.challans:
        raise HTTPException(status_code=404, detail="challan not found")
    data = await slip.read()
    return engine.upload_slip(challan_id, slip.filename, data, hospital_name, timestamp)


@app.get("/api/events")
def events(limit: int = 50):
    return engine.events[-limit:]


@app.get("/api/state")
def state():
    """Everything the map needs: vehicles, timers, challans, recent events."""
    return engine.state()


@app.post("/api/reset")
def reset():
    """Start fresh (clears vehicles, events and challans)."""
    global engine
    engine = CorridorEngine()
    return {"status": "reset"}
