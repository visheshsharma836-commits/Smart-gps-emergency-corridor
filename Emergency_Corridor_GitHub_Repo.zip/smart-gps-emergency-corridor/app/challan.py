"""
Mock e-challan and mock waiver check.

IMPORTANT: This is a prototype. No real challan is sent and no real RTO
portal is connected. A challan here is just a Python dictionary.

Waiver check (mock): in the future this step could use OCR/AI to read the
hospital slip. Today it only checks simple rules:
  - file type is PDF/JPG/PNG and the file is not empty or too big
  - the hospital/clinic name is in our sample list (sample_data/hospitals.csv)
  - the slip is uploaded within 48 hours of the challan
"""
import csv
from pathlib import Path

from . import config

def load_hospitals(csv_path=config.HOSPITALS_FILE):
    with open(csv_path, newline="", encoding="utf-8") as f:
        return {row["hospital_name"].strip().lower() for row in csv.DictReader(f)}


def create_challan(number, plate, now, lat, lon, seconds_in_lane):
    """Make a mock e-challan record. number = 1, 2, 3 ..."""
    return {
        "challan_id": f"ECH-DEMO-{number:05d}",
        "plate": plate,
        "issued_at": now,
        "location": {"lat": lat, "lon": lon},
        "seconds_in_lane": round(seconds_in_lane, 1),
        "amount_inr": config.DEMO_FINE_AMOUNT_INR,
        "status": "ISSUED",
        "note": "Mock e-challan (prototype only, not sent to any real portal)",
    }


def verify_slip(filename, file_bytes, hospital_name, challan, now, hospitals):
    """Return (approved: bool, reasons: list of text)."""
    reasons = []
    extension = Path(filename or "").suffix.lower()
    if extension not in config.ALLOWED_SLIP_TYPES:
        reasons.append("file type must be PDF, JPG or PNG")
    if not file_bytes:
        reasons.append("file is empty")
    elif len(file_bytes) > config.MAX_SLIP_BYTES:
        reasons.append("file is bigger than 5 MB")
    if (hospital_name or "").strip().lower() not in hospitals:
        reasons.append("hospital/clinic is not in the registered list")
    if now - challan["issued_at"] > config.WAIVER_WINDOW_HOURS * 3600:
        reasons.append("slip uploaded after 48 hours")
    return (len(reasons) == 0, reasons)
