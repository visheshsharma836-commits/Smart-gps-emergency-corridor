"""
All the settings of the prototype in one place.
Change a number here and the whole system uses the new value.
"""
from pathlib import Path

# Folder paths
BASE_DIR = Path(__file__).resolve().parent.parent
DATA_DIR = BASE_DIR / "sample_data"
LOG_DIR = BASE_DIR / "logs"

# Sample data files (all FAKE demo data)
CORRIDOR_FILE = DATA_DIR / "corridor_lane.geojson"   # the virtual lane (polygon)
WHITELIST_FILE = DATA_DIR / "vahan_whitelist.csv"    # VAHAN-like list of emergency vehicles
HOSPITALS_FILE = DATA_DIR / "hospitals.csv"          # hospitals/clinics accepted for waivers
ROUTES_FILE = DATA_DIR / "routes.json"               # GPS tracks used by the simulator

# Rules of the corridor
GRACE_SECONDS = 15                 # a private car gets 15 seconds to leave the lane
TEMP_WHITELIST_MINUTES = 30        # helpline SMS gives access for 30 minutes
WAIVER_WINDOW_HOURS = 48           # hospital slip must be uploaded within 48 hours

# Demo fine amount for the mock e-challan.
# (Section 194E of the Motor Vehicles Act is about not giving way to emergency
#  vehicles. In this prototype the amount is only a demo value.)
DEMO_FINE_AMOUNT_INR = 10000

# Mock helpline number (112 is India's emergency number; here it is only a label)
HELPLINE_NUMBER = "112"

# Allowed slip file types and max size for the mock verification
ALLOWED_SLIP_TYPES = {".pdf", ".jpg", ".jpeg", ".png"}
MAX_SLIP_BYTES = 5 * 1024 * 1024   # 5 MB
