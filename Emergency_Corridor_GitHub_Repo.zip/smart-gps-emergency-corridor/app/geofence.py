"""
Geofence = a virtual boundary drawn on the map.
Our corridor is a polygon that covers only the LEFTMOST lane of the road.
We use the "shapely" library to check: is this GPS point inside the polygon?
"""
import json
from shapely.geometry import Point, shape

from . import config


class Geofence:
    def __init__(self, geojson_path=config.CORRIDOR_FILE):
        with open(geojson_path, encoding="utf-8") as f:
            self.geojson = json.load(f)
        feature = self.geojson["features"][0]
        self.name = feature["properties"].get("name", "Emergency Corridor")
        # shape() turns the GeoJSON polygon into a shapely Polygon
        self.polygon = shape(feature["geometry"])

    def contains(self, lat, lon):
        """Return True if the GPS point (lat, lon) is inside the lane.
        Note: GeoJSON and shapely use (x=longitude, y=latitude) order."""
        return self.polygon.contains(Point(lon, lat))
