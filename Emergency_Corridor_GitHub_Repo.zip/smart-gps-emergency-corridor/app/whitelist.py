"""
Whitelist = list of vehicles allowed in the corridor.

1. Permanent list: emergency vehicles from a VAHAN-like CSV file
   (in the real system this would come from the RTO / VAHAN database).
2. Temporary list: private cars carrying a patient. The family sends the
   vehicle number by SMS/WhatsApp to the helpline and gets access for a
   limited time (30 minutes by default).
"""
import csv
import re

from . import config

# Indian number plate pattern, e.g. DL01EA1001, HR26DK9090, MH12AB1234
PLATE_PATTERN = re.compile(r"[A-Z]{2}\d{1,2}[A-Z]{0,3}\d{4}")


def normalize_plate(text):
    """'dl 01 ea 1001' -> 'DL01EA1001'"""
    return re.sub(r"[^A-Z0-9]", "", str(text).upper())


def find_plate(message):
    """Find the first number plate inside an SMS text. Returns None if not found."""
    cleaned = normalize_plate(message)
    match = PLATE_PATTERN.search(cleaned)
    return match.group(0) if match else None


class Whitelist:
    def __init__(self, csv_path=config.WHITELIST_FILE):
        self.permanent = {}      # plate -> row from CSV
        self.temporary = {}      # plate -> {"until": timestamp, "destination": text}
        with open(csv_path, newline="", encoding="utf-8") as f:
            for row in csv.DictReader(f):
                self.permanent[normalize_plate(row["plate"])] = row

    def is_permanent(self, plate):
        return normalize_plate(plate) in self.permanent

    def is_temporary(self, plate, now):
        info = self.temporary.get(normalize_plate(plate))
        return info is not None and now < info["until"]

    def is_allowed(self, plate, now):
        return self.is_permanent(plate) or self.is_temporary(plate, now)

    def reason(self, plate, now):
        if self.is_permanent(plate):
            return "VAHAN whitelist (" + self.permanent[normalize_plate(plate)]["vehicle_type"] + ")"
        if self.is_temporary(plate, now):
            return "temporary helpline whitelist"
        return None

    def add_temporary(self, plate, now, destination=""):
        until = now + config.TEMP_WHITELIST_MINUTES * 60
        self.temporary[normalize_plate(plate)] = {"until": until, "destination": destination}
        return until
