"""
The brain of the system: CorridorEngine.

Every time a vehicle sends its GPS position, the engine decides:
  - Is the vehicle inside the virtual lane?
  - Is it allowed (VAHAN whitelist or temporary helpline whitelist)?
  - If not allowed: start a 15-second timer.
  - If the timer finishes and the car is still inside: create an e-challan.
  - If the car leaves in time, or the family sends an SMS: stop the timer.

All times are numbers in seconds (like time.time()). Passing the time in
makes the logic easy to test and to simulate.
"""
import time

from . import challan as challan_module
from . import config
from .geofence import Geofence
from .whitelist import Whitelist, find_plate, normalize_plate


class CorridorEngine:
    def __init__(self, geofence=None, whitelist=None):
        self.geofence = geofence or Geofence()
        self.whitelist = whitelist or Whitelist()
        self.hospitals = challan_module.load_hospitals()
        self.vehicles = {}   # plate -> latest state of that vehicle
        self.challans = {}   # challan_id -> challan
        self.events = []     # list of everything that happened (the log)
        self.last_time = None

    # ---------- small helpers ----------
    def _now(self, now):
        if now is None:
            now = time.time()
        self.last_time = now
        return now

    def _log(self, now, kind, plate, message, **extra):
        event = {"time": now, "event": kind, "plate": plate, "message": message}
        event.update(extra)
        self.events.append(event)
        return event

    def _vehicle(self, plate):
        if plate not in self.vehicles:
            self.vehicles[plate] = {
                "plate": plate,
                "lat": None,
                "lon": None,
                "in_lane": False,
                "status": "OUTSIDE",          # OUTSIDE / ALLOWED / TIMER / CHALLANED
                "timer_started": None,
                "challan_id": None,
            }
        return self.vehicles[plate]

    # ---------- main step: a GPS update ----------
    def update_gps(self, plate, lat, lon, now=None):
        """Process one GPS point. Returns the list of new events."""
        now = self._now(now)
        plate = normalize_plate(plate)
        v = self._vehicle(plate)
        v["lat"], v["lon"] = lat, lon
        start = len(self.events)

        inside = self.geofence.contains(lat, lon)
        was_inside = v["in_lane"]
        v["in_lane"] = inside

        if not inside:
            if was_inside:
                if v["status"] == "TIMER":
                    secs = now - v["timer_started"]
                    self._log(now, "LEFT_IN_TIME", plate,
                              f"{plate} left the lane after {secs:.0f}s. Timer cancelled, no challan.")
                else:
                    self._log(now, "EXITED_LANE", plate, f"{plate} left the corridor.")
            v["status"] = "OUTSIDE"
            v["timer_started"] = None
            return self.events[start:]

        # Vehicle is inside the lane
        if self.whitelist.is_allowed(plate, now):
            if v["status"] != "ALLOWED":
                reason = self.whitelist.reason(plate, now)
                self._log(now, "ACCESS_GRANTED", plate,
                          f"{plate} entered the corridor. Allowed: {reason}.")
            v["status"] = "ALLOWED"
            v["timer_started"] = None
        elif not was_inside:
            v["status"] = "TIMER"
            v["timer_started"] = now
            self._log(now, "TIMER_STARTED", plate,
                      f"{plate} is NOT whitelisted. Warning sent: leave the lane within "
                      f"{config.GRACE_SECONDS} seconds or SMS the helpline {config.HELPLINE_NUMBER}.")

        self._check_timer(v, now)
        return self.events[start:]

    def _check_timer(self, v, now):
        """If the 15-second timer is over and the car is still inside -> e-challan."""
        if v["status"] == "TIMER" and now - v["timer_started"] >= config.GRACE_SECONDS:
            ch = challan_module.create_challan(len(self.challans) + 1, v["plate"], now, v["lat"], v["lon"],
                                               now - v["timer_started"])
            self.challans[ch["challan_id"]] = ch
            v["status"] = "CHALLANED"
            v["challan_id"] = ch["challan_id"]
            self._log(now, "E_CHALLAN_ISSUED", v["plate"],
                      f"{v['plate']} stayed more than {config.GRACE_SECONDS}s. "
                      f"Mock e-challan {ch['challan_id']} created (Rs {ch['amount_inr']}).",
                      challan_id=ch["challan_id"])

    def tick(self, now=None):
        """Check all running timers (call this every second)."""
        now = self._now(now)
        start = len(self.events)
        for v in self.vehicles.values():
            if v["in_lane"]:
                self._check_timer(v, now)
        return self.events[start:]

    # ---------- helpline SMS / WhatsApp ----------
    def helpline_message(self, from_number, message, now=None):
        """A family sends e.g. 'EMERGENCY DL03CQ7788 patient to AIIMS'.
        We find the plate and give temporary access. Returns the reply text."""
        now = self._now(now)
        plate = find_plate(message)
        if plate is None:
            return {"ok": False, "plate": None,
                    "reply": "Vehicle number not found. Please send like: EMERGENCY DL03CQ7788"}

        destination = message.upper().split(plate, 1)[-1].strip() if plate in message.upper() else ""
        until = self.whitelist.add_temporary(plate, now, destination)
        v = self._vehicle(plate)
        self._log(now, "TEMP_WHITELISTED", plate,
                  f"Helpline message from {from_number}: {plate} temporarily whitelisted "
                  f"for {config.TEMP_WHITELIST_MINUTES} min.")
        if v["status"] == "TIMER":
            self._log(now, "TIMER_STOPPED", plate,
                      f"Timer stopped for {plate} after {now - v['timer_started']:.0f}s. No challan.")
        if v["in_lane"]:
            v["status"] = "ALLOWED"
            v["timer_started"] = None
        return {"ok": True, "plate": plate, "valid_until": until,
                "reply": f"Temporary Corridor Access Granted for {plate} "
                         f"(valid {config.TEMP_WHITELIST_MINUTES} min). Drive safely."}

    # ---------- hospital slip upload -> waiver ----------
    def upload_slip(self, challan_id, filename, file_bytes, hospital_name, now=None):
        now = self._now(now)
        ch = self.challans.get(challan_id)
        if ch is None:
            return {"ok": False, "reasons": ["challan not found"]}
        if ch["status"] != "ISSUED":
            return {"ok": False, "reasons": [f"challan is already {ch['status']}"]}
        approved, reasons = challan_module.verify_slip(
            filename, file_bytes, hospital_name, ch, now, self.hospitals)
        if approved:
            ch["status"] = "WAIVED"
            ch["waiver"] = {"hospital": hospital_name, "file": filename, "at": now}
            self._log(now, "WAIVER_APPROVED", ch["plate"],
                      f"Slip from '{hospital_name}' accepted (mock check). Challan {challan_id} waived.",
                      challan_id=challan_id)
        else:
            self._log(now, "WAIVER_REJECTED", ch["plate"],
                      f"Slip for {challan_id} rejected: {'; '.join(reasons)}.",
                      challan_id=challan_id)
        return {"ok": approved, "challan_id": challan_id, "status": ch["status"], "reasons": reasons}

    def challan_for_plate(self, plate):
        plate = normalize_plate(plate)
        for ch in reversed(list(self.challans.values())):
            if ch["plate"] == plate:
                return ch
        return None

    # ---------- for the map ----------
    def state(self):
        """Current picture of all vehicles (used by the web map)."""
        now = self.last_time
        items = []
        for v in self.vehicles.values():
            item = dict(v)
            item["whitelisted"] = self.whitelist.is_permanent(v["plate"])
            item["temporary"] = now is not None and self.whitelist.is_temporary(v["plate"], now)
            if v["status"] == "TIMER" and now is not None:
                item["seconds_left"] = max(0, round(config.GRACE_SECONDS - (now - v["timer_started"])))
            items.append(item)
        return {"time": now, "vehicles": items, "challans": list(self.challans.values()),
                "events": self.events[-15:]}
